#!/usr/bin/env bash
echo "Custom-Utility"
echo "Hello $1"